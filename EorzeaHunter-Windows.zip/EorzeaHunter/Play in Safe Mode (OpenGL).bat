@echo off
rem Starts the game with the OpenGL renderer. Use this if the normal launch shows a black screen.
start "" "%~dp0EorzeaHunter.exe" --rendering-driver opengl3
